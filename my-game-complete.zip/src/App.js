import React, { useState } from 'react';
import Start from './components/Start';
import Menu from './components/Menu';
import Game from './components/Game';
import Settings from './components/Settings';

export default function App(){
  const [screen, setScreen] = useState('start');
  return <>
    {screen==='start' && <Start changeScreen={setScreen}/>}
    {screen==='menu' && <Menu changeScreen={setScreen}/>}
    {screen==='game' && <Game changeScreen={setScreen}/>}
    {screen==='settings' && <Settings changeScreen={setScreen}/>}
  </>
}