import React from 'react';

export default function Start({changeScreen}){
  return (
    <div className='screen'>
      <h1>🔥 Bem-vindo ao Meu Jogo</h1>
      <button onClick={()=>changeScreen('menu')}>Entrar</button>
    </div>
  );
}