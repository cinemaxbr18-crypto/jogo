import React from 'react';

export default function Clicker({addScore}){
  return (
    <div>
      <h3>MiniGame: Clicker</h3>
      <button onClick={addScore}>+1 ponto</button>
    </div>
  );
}