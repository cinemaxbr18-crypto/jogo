import React from 'react';

export default function Menu({changeScreen}){
  return (
    <div className='screen'>
      <h1>🎮 Menu</h1>
      <button onClick={()=>changeScreen('game')}>Iniciar Jogo</button>
      <button onClick={()=>changeScreen('settings')}>Configurações</button>
    </div>
  );
}