import React from 'react';

export default function Settings({changeScreen}){
  return (
    <div className='screen'>
      <h1>⚙️ Configurações</h1>
      <p>Ajustes futuros…</p>
      <button className='back' onClick={()=>changeScreen('menu')}>Voltar</button>
    </div>
  );
}