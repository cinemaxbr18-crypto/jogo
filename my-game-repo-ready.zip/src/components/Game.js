import React, { useState } from 'react';
import Minigame from './minigames/Clicker';

export default function Game({changeScreen}){
  const [score,setScore]=useState(0);

  return (
    <div className='screen'>
      <h1>🕹️ Jogo</h1>
      <p>Pontuação: {score}</p>

      <Minigame addScore={()=>setScore(score+1)}/>

      <button className='back' onClick={()=>changeScreen('menu')}>Voltar</button>
    </div>
  );
}